import React from 'react'
import "../styles/CommentBox.css";

const CommentBox = () => {
  return (
    <div>

    </div>
  )
}

export default CommentBox
