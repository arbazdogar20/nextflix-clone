export const mockComments = [
    {username: "john doe", comment: "horrible movie", rating: 4, createdAt: "2025-07-11"},
    {username: "john doe", comment: "horrible movie", rating: 4, createdAt: "2025-07-11"},
    {username: "john doe", comment: "horrible movie", rating: 4, createdAt: "2025-07-11"}
]